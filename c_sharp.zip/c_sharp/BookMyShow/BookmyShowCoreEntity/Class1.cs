﻿namespace BookmyShowCoreEntity
{
    public class Class1
    {

    }
}