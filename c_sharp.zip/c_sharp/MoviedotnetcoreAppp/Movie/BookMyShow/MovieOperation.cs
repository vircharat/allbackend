﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using MovieEntity.Data;
using MovieEntity.Models;

namespace MovieEntity.BookMyShow
{
    public class MovieOperation
    {
        MovieDbContext db = null;

    

        public string AddMovie(Movie movie)
        {
            db = new MovieDbContext();
            db.Movies.Add(movie);
            db.SaveChanges();
            return "saved";
        }

        public string UpdateMovie(Movie movie)
        {
            db=new MovieDbContext();
            db.Entry(movie).State=EntityState.Modified;
            db.SaveChanges();
            return "updated";
        }
        public string DeleteMovie(int movieId)
        {
            db = new MovieDbContext();
            Movie movie =db.Movies.Find(movieId);
            db.Entry(movie).State=EntityState.Deleted;
            db.SaveChanges();
            return "deleted";
        }
        public List<Movie> ShowAll()
        {   db = new MovieDbContext();
            List<Movie> list = db.Movies.ToList();

            return list;
        }
        public List<Movie> ShowAllByMovieType(string type)
        {
            db = new MovieDbContext();
            List<Movie> movieList = db.Movies.ToList();

            //LINQ query select * from movie where movietype='type'
            var result=from Movies in movieList
                       where Movies.MovieType == type
                       orderby Movies.Name descending
                       select Movies;
            List<Movie> movieResult= new List<Movie>();
            foreach(var item in result)//linq query execution
            {
                movieResult.Add(item);
            }
            return movieResult;

        }
        public List<Movie> ShowAllByMovieTypeDisplaynameonly(string type)
        {
            db = new MovieDbContext();
            List<Movie> movieList = db.Movies.ToList();

            //LINQ query select * from movie where movietype='type'
            var result = from Movies in movieList
                         where Movies.MovieType == type
                         orderby Movies.Name descending
                         select new Movie { 
                         Id=Movies.Id,
                         Name=Movies.Name,  
                         };

            List<Movie> movieResult = new List<Movie>();
            foreach (var item in result)//linq query execution
            {
                movieResult.Add(item);
            }
            return movieResult;

        }

        public Movie ShowMovieByid(int movieId)
        {
            db = new MovieDbContext();
            Movie movie=db.Movies.Find(movieId);
            return movie;
        }

        

    }
}
