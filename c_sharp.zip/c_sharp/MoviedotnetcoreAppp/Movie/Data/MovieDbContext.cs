﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using MovieEntity.Models;

namespace MovieEntity.Data
{
    public class MovieDbContext:DbContext
    {
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Theatre> theatres { get; set; }
        public DbSet<ShowTiming > showTimings { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
        {
            dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LTC2179;Initial Catalog=MovieAppDatabasee;Integrated Security=True;");
        }
    }
}
