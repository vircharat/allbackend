﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace MovieEntity.Models
{
    public class Theatre
    {
        [Key]

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TheatreId { get; set; }
        public string TheatreName { get; set; }

        public string TheatreAddress { get; set; }

        public string TheatreComments { get; set; }  
        

    }
}
