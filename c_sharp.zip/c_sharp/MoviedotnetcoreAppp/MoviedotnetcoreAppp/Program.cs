﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MoviedotnetcoreAppp
{
    public class Program
    {
        static void Main(string[] args)
        {
            MoviePL moviePL=new MoviePL();
            bool flag = true; ;
            while(flag)
            {
                Console.WriteLine("-----------------------------------------------------------------------------------------\n" +
                    "__________________________________________________________________________________________");
               flag= moviePL.menu();
            }

        /* List<int> values=new List<int>()
         {
             1,2,3,32,56,53,23,11,45,55,67
         };
            var result=from obj in values
                       where obj>50
                       orderby obj descending
                       select obj;
            foreach(var item in result)
            {
                Console.WriteLine(item);
            }*/
        }
    }
}
