﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using MovieEntity;
using MovieEntity.BookMyShow;
using MovieEntity.Data;
using MovieEntity.Models;

namespace MoviedotnetcoreAppp
{
    public class MoviePL
    {
         public bool  menu()
         {
            bool flag = false; 
            MoviePL moviePLObj=new MoviePL();   
            Console.WriteLine("Welcome to movie app");
            Console.WriteLine("To choose the function");
      
            Console.WriteLine("Enter 1 to add\n" +
                "Enter 2 to deletet move\n" +
                "Enter 3 to Show Movie by its id\n" +
                "Enter 4 to show all movies\n" +
                "Enter 5 to Update movies\n" +
                "Enter 6 to show by type of movie\n" +
                "Enter 7 to show name and id by type of movie\n" +
                "Enter 8 to exit");
            int codeentered;
            codeentered =Convert.ToInt32( Console.ReadLine());
            switch (codeentered)
            {

                case 1:
                    moviePLObj.AddMovie();
                    flag = true;
                    
                    break;
                case 2:
                    moviePLObj.DeleteMovie();
                    flag = true;
                    break;
                case 3:
                    moviePLObj.ShowMovieById();
                    flag = true;
                    break;
                case 4:
                    moviePLObj.ShowAllMovies();
                    flag = true;
                    break;
                case 5:
                    moviePLObj.UpdateMovie();
                    flag = true;
                    break;
                case 6:
                    moviePLObj.ShowAllByMovieType();
                    flag = true;
                    break;
                case 7:
                    moviePLObj.ShowAllByMovieTypeDisplaynameonly();
                    flag = true;
                    break;
                case 8:
                    flag = false;
                    break;
                
                default:
                    Console.WriteLine("Invalid code");

                    break;



              
                    
            }
            return flag;



        }
        public void UpdateMovie()
        {
            MovieEntity.Models.Movie movie = new MovieEntity.Models.Movie();
            MovieOperation movieOperation = new MovieOperation();
            Console.WriteLine("Enter the Movie Id");
            movie.Id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Movie Name : ");
            movie.Name = Console.ReadLine();

            Console.WriteLine("Enter Movie Type : ");
            movie.MovieType = Console.ReadLine();
            Console.WriteLine("Movie Description  : ");
            movie.MovieDesc = Console.ReadLine();
            string msg = movieOperation.UpdateMovie(movie);
            Console.WriteLine(msg);

        }
        public void AddMovie()
         {
            MovieEntity.Models.Movie movie=new MovieEntity.Models.Movie();
            MovieOperation movieOperation = new MovieOperation();
            Console.WriteLine("Enter Movie Name : ");
            movie.Name=Console.ReadLine();
         
            Console.WriteLine("Enter Movie Type : ");
            movie.MovieType = Console.ReadLine();
            Console.WriteLine("Movie Description  : ");
            movie.MovieDesc = Console.ReadLine();
            string msg = movieOperation.AddMovie(movie);
            Console.WriteLine(msg);

        }
       public void ShowAllByMovieType()
        {
            Movie movie = new Movie();
            MovieOperation movieOperation = new MovieOperation();
            Console.WriteLine("Enter Movie Type : ");
            movie.MovieType = Console.ReadLine();
            List<Movie>movies=movieOperation.ShowAllByMovieType(movie.MovieType);
            foreach(var item in movies)
            {
                Console.WriteLine(item.Id);
                Console.WriteLine(item.Name);
                Console.WriteLine(item.MovieDesc);
                Console.WriteLine(item.MovieType);

            }


        }
        public void ShowAllByMovieTypeDisplaynameonly()
        {
            Movie movie = new Movie();
            MovieOperation movieOperation = new MovieOperation();
            Console.WriteLine("Enter Movie Type : ");
            movie.MovieType = Console.ReadLine();
            List<Movie> movies = movieOperation.ShowAllByMovieTypeDisplaynameonly(movie.MovieType);
            foreach (var item in movies)
            {
                Console.WriteLine(item.Id);
                Console.WriteLine(item.Name);
              
            }


        }

        public void DeleteMovie()
        {
            Movie movie = new Movie();
            MovieOperation movieOperation = new MovieOperation();
            Console.WriteLine("Enter Movie Id : ");
            movie.Id= Convert.ToInt32(Console.ReadLine());
            string msg = movieOperation.DeleteMovie(movie.Id);
            Console.WriteLine(msg);
        }
        public void ShowMovieById()
        {
            Movie movie = new Movie();
            MovieOperation movieOperation = new MovieOperation();
            Console.WriteLine("Enter Movie Id : ");
            movie.Id = Convert.ToInt32(Console.ReadLine());
            movie = movieOperation.ShowMovieByid(movie.Id);
            Console.WriteLine(movie.Name);
        }


        public void ShowAllMovies()
        {
            MovieEntity.Models.Movie movie = new MovieEntity.Models.Movie();
            MovieOperation movieOperation = new MovieOperation();
            List<MovieEntity.Models.Movie> movies = movieOperation.ShowAll();
            foreach(var item in movies)
            {
                Console.WriteLine("Id : " + item.Id);
                Console.WriteLine("Name : "+item.Name);
                Console.WriteLine("Description : "+item.MovieDesc);
                Console.WriteLine("Movie Type : "+item.MovieType);

            }

        }

    }
}
