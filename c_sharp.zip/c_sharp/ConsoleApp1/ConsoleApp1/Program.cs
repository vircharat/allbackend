﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsHARP2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Report reportObj = new Report();
            /*dictionarydemo dictionarydemoObj = new dictionarydemo();
            dictionarydemoObj.getempdetails();*/
            MyDelegateReport myDelegateReport = new MyDelegateReport(reportObj.pdfReport);
            myDelegateReport+=new MyDelegateReport(reportObj.excelReport);
            myDelegateReport += new MyDelegateReport(reportObj.xmlReport);
            string role = "user";
            if (role == "user")
            {
                myDelegateReport("");
            }
            else
            {
                myDelegateReport -= new MyDelegateReport(reportObj.xmlReport);//multicasting
                myDelegateReport("");
            }
        }
    }
}
