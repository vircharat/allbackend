﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CsHARP2
{
    public class dictionarydemo
    {   
        public void getempdetails()
        {
            Dictionary<int, string> empData = new Dictionary<int, string>();
            empData.Add(101, "Chandan");
            empData.Add(102, "kiran");
            empData.Add(103, "kohli");

            var value = empData[101];
            var a=10;
            var b = "20";
            dynamic d1 = 10;
            dynamic d2 = 20;
            foreach (var item in empData)
            {
                Console.WriteLine(item.Value);
            }

        }
    }
}
