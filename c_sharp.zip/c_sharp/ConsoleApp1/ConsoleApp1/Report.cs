﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsHARP2
{
    public delegate void MyDelegateReport(string name);
    public class Report
    {
        public void pdfReport(string filename)
        {
         
        }

        public void excelReport(string filename)
        {

        }

        public void xmlReport(string filename)
        {
            
        }

        public void MyReport()
        {
            
        }

    }
}
