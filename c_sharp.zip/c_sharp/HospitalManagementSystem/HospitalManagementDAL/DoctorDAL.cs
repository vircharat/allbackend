﻿using HospitalManagementEntityy;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementDAL
{
    public class DoctorDAL
    {
        public static string sqlcon = "Data Source=VDC01LTC2179; Initial Catalog=HospitalManagementService; Integrated Security=True;";
        public List<Doctor>doctors = new List<Doctor>();
        string msg = "";

        public bool common(string commonstring)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(sqlcon);
            SqlCommand cmd = new SqlCommand(commonstring, con);
            con.Open();
            int row = cmd.ExecuteNonQuery();
            con.Close();
            if(row > 0)
            {
                return true;
            }


            return false;
        }

        public string AddDoctorDAL(Doctor doctor)
        {

            
            string commonstring = "insert into Doctor values(" +doctor.DoctorId + ",'" +doctor.DoctorName + "','" + doctor.DoctorEmail + "','" +doctor.DoctorPassword + "','" + doctor.DoctorSpeciality + "')";
            bool flag=false;
            flag=common(commonstring);
            if (flag)
            {
                msg = "Doctor Inserted successfully";
                
            }
            return msg;
        }



        public string UpadateDoctorDAl(Doctor doctor)
        {
            bool flag = false;
            var commonstring = "Update Doctor set DoctorId=" + doctor.DoctorId + ", DoctorName='" + doctor.DoctorName + "',DoctorEmail='" + doctor.DoctorEmail + "',DoctorPassword='" + doctor.DoctorPassword + "', DoctorSpeciality='" + doctor.DoctorSpeciality + "'where DoctorId=" + doctor.DoctorId;
            flag = common(commonstring);
            if (flag)
            {
                msg = "doctor Updated successfull";
                
            }



            return msg;
        }



        public string DeleteDoctorDAL(int DoctorId)

        {
            
            bool flag = false;
            var commonstring = "Delete from Doctor where DoctorId=" + DoctorId;
            flag= common(commonstring);
            if (row > 0)
            {

                msg = "doctor Deleted Successfully,...  :)";
                
            }



            return msg;
        }



        public List<Doctor> ShowAllDoctorDAL()
        {
            SqlConnection conn = new SqlConnection(sqlcon);
            SqlDataAdapter adp = new SqlDataAdapter("Select * from Doctor ", conn);
            DataTable dt = new DataTable();
            List<Doctor> doctorList = new List<Doctor>();
            adp.Fill(dt);



            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    doctorList.Add(new Doctor
                    {
                        DoctorId = Convert.ToInt32(dt.Rows[i]["DoctorId"]),
                        DoctorName = dt.Rows[i]["DoctorName"].ToString(),
                        DoctorEmail = dt.Rows[i]["DoctorEmail"].ToString(),
                        DoctorPassword = dt.Rows[i]["DoctorPassword"].ToString(),
                        DoctorSpeciality = dt.Rows[i]["DoctorSpeciality"].ToString()
                    });
                }
            }



            return doctorList;
        }
        /*      public List<T> ShowAll<T>()
       {
           SqlConnection conn = new SqlConnection(sqlcon);
           SqlDataAdapter adp = new SqlDataAdapter("Select * from Doctor ", conn);
           DataTable dt = new DataTable();
           List<Doctor> doctorList = new List<Doctor>();
           adp.Fill(dt);



           if (dt != null && dt.Rows.Count > 0)
           {
               for (int i = 0; i < dt.Rows.Count; i++)
               {
                   doctorList.Add(new Doctor
                   {
                       DoctorId = Convert.ToInt32(dt.Rows[i]["DoctorId"]),
                       DoctorName = dt.Rows[i]["DoctorName"].ToString(),
                       DoctorEmail = dt.Rows[i]["DoctorEmail"].ToString(),
                       DoctorPassword = dt.Rows[i]["DoctorPassword"].ToString(),
                       DoctorSpeciality = dt.Rows[i]["DoctorSpeciality"].ToString()
                   });
               }
           }



           return list;
       }
       public void data()
       {
           List<Doctor> list = ShowAll<Doctor>();
           List<Admin> list = ShowAll<Admin>();
           List<Doctor> list = ShowAll<Doctor>();
       }*/
    }
}
