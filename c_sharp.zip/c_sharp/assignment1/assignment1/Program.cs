﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography.X509Certificates;

namespace assignment1
{
    public class Program
    {
        #region first object
        static void Main(string[] args)
        {

            var people = new List<Person>()

             { new Person("Bill", "Smith", 41),
            new Person("Sarah", "Jones", 22),
            new Person("Stacy","Baker", 21),
            new Person("Vivianne","Dexter", 19 ),
            new Person("Bob","Smith", 49 ),
            new Person("Brett","Baker", 51 ),
            new Person("Mark","Parker", 19),
            new Person("Alice","Thompson", 18),
            new Person("Evelyn","Thompson", 58 ),
            new Person("Mort","Martin", 58),
            new Person("Eugene","deLauter", 84 ),
            new Person("Gail","Dawson", 19 ),

        };
            Program program = new Program();
            List<Person> person = program.lastnamewith_d(people);
            foreach (var item in person)
            {
                Console.WriteLine(item.LastName);
            }//1

            int a = program.countlastwith_d(people);
            Console.WriteLine(a);//2

            List<Person> person40 = program.olderthan(people);
            foreach (var item in person40)
            {
                Console.WriteLine(item.FirstName);
                Console.WriteLine(item.Age);
            }//3

            List<string> sa = program.concate(people);

            foreach (var item in sa)
            {
                Console.WriteLine(item);
            }//4
            #endregion

            Console.WriteLine("enter string");
            string name = Console.ReadLine();
            program.repeat(name);//2.1

            List<string> namelist = new List<string> { "abc", "xyz", "klm", "xyz", "abc", "abc", "rst" };

            List<string> namelistanswer = program.uniquer(namelist);

            foreach (var item in namelistanswer)
            {
                Console.WriteLine(item);
            }//2.2

            program.top5();//2.3
            program.collectl();//2.4

            program.multiple4r5();//2.5

            program.howmany();//2.6

            program.moneymade();//2.7

            program.expensive();//2.8

            program.millonire();//2.9




        }
        #region first
        public class Person
        {
            public Person(string firstName, string lastName, int age)
            {
                FirstName = firstName;
                LastName = lastName;
                Age = age;
            }

            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int Age { get; set; }

            //override ToString to return the person's FirstName LastName Age
        }

        public class MovieDBcontextv : DbContext
        {
            public DbSet<Person> person { get; set; }

            protected override void OnConfiguring(DbContextOptionsBuilder dbContextOptionsBuilder)
            {
                dbContextOptionsBuilder.UseSqlServer("Data Source=VDC01LTC2179;Initial Catalog=BookTheShowv;Integrated Security=True;");
            }
        }
        public List<Person> lastnamewith_d(List<Person> people)
        {


            //LINQ query select * from movie where movietype='type'
            var result = from obj in people
                         where obj.LastName.StartsWith('D') || obj.LastName.StartsWith('d')
                         select obj;
            List<Person> personResult = new List<Person>();
            foreach (var item in result)//linq query execution
            {
                personResult.Add(item);
            }

            return personResult;

        }//1

        public int countlastwith_d(List<Person> people)
        {
            int count = 0;
            var result = from obj in people
                         where obj.LastName.StartsWith('D') || obj.LastName.StartsWith('d')//.count()
                         select obj;
            List<Person> personResult = new List<Person>();
            foreach (var item in result)//linq query execution
            {
                personResult.Add(item);
                count++;
            }

            return count;
        }//2

        public List<Person> olderthan(List<Person> people)
        {


            //LINQ query select * from movie where movietype='type'
            var result = from obj in people
                         where obj.Age > 40
                         orderby obj.FirstName descending
                         select obj;
            List<Person> personResult = new List<Person>();
            foreach (var item in result)//linq query execution
            {
                personResult.Add(item);
            }

            return personResult;

        }//3

        public List<string> concate(List<Person> people)
        {


            //LINQ query select * from movie where movietype='type'
            var result = from obj in people
                         select obj.FirstName + " " + obj.LastName;

            List<string> personResult = new List<string>();
            foreach (var item in result)//linq query execution
            {
                personResult.Add(item);
            }

            return personResult;




        }//4
        #endregion

        public void repeat(string name)
        {

            var qry = (from c in name.ToCharArray()
                       group c by c into g
                       where g.Count() > 1
                       select g.Key);
            foreach (var item in qry)
            {
                Console.WriteLine(item);
            }

        }//2.1


        public List<string> uniquer(List<string> namelist)
        {
            var result = (from obj1 in namelist
             
                          group obj1 by obj1 into grp
                          select  new { cnt = grp.Count(), key = grp.Key });
            List<string> personResult = new List<string>();
            foreach (var item in result)//linq query execution
            { 
                if(item.cnt == 1)
                personResult.Add(item.key);
            }

            return personResult;
        }//2.2

        public void top5()
        {

            List<int> arr = new List<int>() {1,2,3,-1,6,7,8 };
            var result = (from obj in arr
                         orderby obj ascending
                         select obj).Take(5);
            foreach(var item in result)
            {
                Console.WriteLine(item);
            }

        }//2.3
     

        public void collectl()
        {
            List<string> fruits = new List<string>() { "Lemon", "Apple", "Orange", "Lime", "Watermelon", "Loganberry" };
            var result = (from obj in fruits
                         where obj.StartsWith('L')
                         select obj).ToList();
            foreach(var item in result)
            {
                Console.WriteLine(item);
            }
        }//2.4

        public void multiple4r5()
        {
            List<int> mixedNumbers = new List<int>()
            {
                15, 8, 21, 24, 32, 13, 30, 12, 7, 54, 48, 4, 49, 96
            };
            var result = (from obj in mixedNumbers

                          where obj%4==0 ||obj%6==0
                         select obj).ToList();
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }

        }//2.5

        public void howmany()
        {
            List<int> numbers = new List<int>()
            {
                15, 8, 21, 24, 32, 13, 30, 12, 7, 54, 48, 4, 49, 96
            };

            var result=(from obj in numbers

                       select obj).Count();
            Console.WriteLine(result);

        }//2.6

        public void moneymade()
        {
            List<double> purchases = new List<double>()
          {
                2340.29, 745.31, 21.76, 34.03, 4786.45, 879.45, 9442.85, 2454.63, 45.65
            };
            var result = (from obj in purchases
                         select obj).Sum();
            Console.WriteLine(result);

        }//2.7

        public void expensive()//2.8
        {
            List<double> prices = new List<double>()
            {
                879.45, 9442.85, 2454.63, 45.65, 2340.29, 34.03, 4786.45, 745.31, 21.76
            };

            var result=(from obj in prices
                       select obj).Max();
            Console.WriteLine(result);
        }


        public void millonire()
        {
            List<Customer> customers = new List<Customer>() {
                new Customer(){ Name="Bob Lesman", Balance=80345.66, Bank="FTB"},
                new Customer(){ Name="Joe Landy", Balance=9284756.21, Bank="WF"},
                new Customer(){ Name="Meg Ford", Balance=487233.01, Bank="BOA"},
                new Customer(){ Name="Peg Vale", Balance=7001449.92, Bank="BOA"},
                new Customer(){ Name="Mike Johnson", Balance=790872.12, Bank="WF"},
                new Customer(){ Name="Les Paul", Balance=8374892.54, Bank="WF"},
                new Customer(){ Name="Sid Crosby", Balance=957436.39, Bank="FTB"},
                new Customer(){ Name="Sarah Ng", Balance=56562389.85, Bank="FTB"},
                new Customer(){ Name="Tina Fey", Balance=1000000.00, Bank="CITI"},
                new Customer(){ Name="Sid Brown", Balance=49582.68, Bank="CITI"}
            };

            var result = (from obj in customers
                          where obj.Balance >= 1000000
                          group obj.Bank by obj.Bank into grou
                          select new {
                              cnt = grou.Count(),
                           key=grou.Key
                           

                              

                             }).ToList();
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }



        }//2.9
        public class Customer
        {
            public string Name { get; set; }
            public double Balance { get; set; }

            public string Bank { get; set; }

            public Customer()
            {
           
            }


        }

        public void mill3()
        {
            List<Customer> customers = new List<Customer>() {
                new Customer(){ Name="Bob Lesman", Balance=80345.66, Bank="FTB"},
                new Customer(){ Name="Joe Landy", Balance=9284756.21, Bank="WF"},
                new Customer(){ Name="Meg Ford", Balance=487233.01, Bank="BOA"},
                new Customer(){ Name="Peg Vale", Balance=7001449.92, Bank="BOA"},
                new Customer(){ Name="Mike Johnson", Balance=790872.12, Bank="WF"},
                new Customer(){ Name="Les Paul", Balance=8374892.54, Bank="WF"},
                new Customer(){ Name="Sid Crosby", Balance=957436.39, Bank="FTB"},
                new Customer(){ Name="Sarah Ng", Balance=56562389.85, Bank="FTB"},
                new Customer(){ Name="Tina Fey", Balance=1000000.00, Bank="CITI"},
                new Customer(){ Name="Sid Brown", Balance=49582.68, Bank="CITI"}
            };

            var result = from obj in customers
                         group obj.Bank by obj.Bank into grou
                         select new
                         {
                             grou.Count,
                             key=grou.Key
                         };
            
                         
                        
                      


        }













    }


}
