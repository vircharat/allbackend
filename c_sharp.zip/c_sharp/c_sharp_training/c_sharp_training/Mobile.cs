﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_sharp_training
{
    public  class Mobile //public abstract class Mobile
    {
        private int IMENo;

        public string Model { get; set; } 


        public int Year { get; set; }

       


    }
    public class Nokia :  Mobile
    {
        public void NokiaConfig()
        {

        }

    }

    public class samsung : Mobile
    {
        public void SamsungConfig()
        {

        }
    
    }




}
