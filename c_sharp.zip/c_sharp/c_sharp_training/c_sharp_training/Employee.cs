﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace c_sharp_training
{
    public class Employee
    {
        public int Id { get; set; }
        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public string Email { get; set; }

        public int Mobile { get; set; }
        
         

        public void CreateEmployee()
        {
            int[] empids = new int[3]; //array declaration
           
            string[] names=new string[3]; //string declaration

            int[] numbers = { 3, 4, 54, 6 }; //array initialiation
            
            for (int i = 0; i <names.Length; i++)
            {
                Console.Write("Enter Id: ");
                empids[i] = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter name : ");
                names[i] = Console.ReadLine();
            }

            for(int i = 0; i < names.Length; i++)
            {
                Console.WriteLine(empids[i]);
                Console.WriteLine(names[i]);
                Console.ReadLine();
            }
            
/*            Console.Write("Enter Id: ");
            Id=Convert.ToInt32(Console.ReadLine());
           
            Console.Write("Enter Firstname: ");
            Firstname=Console.ReadLine();
           
            Console.Write("Enter Lastname: ");
            Lastname=Console.ReadLine();    
            
            Console.Write("Enter Email: ");
            Email=Console.ReadLine();
           
            Console.Write("Enter Mobile: ");
            Mobile=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Created...");

            Console.WriteLine("************");
            Console.WriteLine("Employee Details: " +Id+ "," +Firstname+ "," +Lastname+ "," +Email+ "," +Mobile); */

        }

        public void UpdateEmployee()
        {
           
            /*  Id = 11;
            Firstname = "Rajesh";
            Lastname = "vinay";
            Email = "Rajes@gamil.com";
            Mobile = 548548;
            Console.WriteLine("************");
            Console.WriteLine("Updated...");*/
        }

        public void GetEmployeeName()
        {
            try
            {
                Console.Write("ENTER the acno: ");
                //string name=Console.ReadLine();
                int acno = Convert.ToInt32(Console.ReadLine());

            }
            catch(FormatException ex)
            {
                Console.WriteLine("invalid input");
            }
            catch(Exception ex)
            {
                //Console.WriteLine(ex.Message);
                Console.WriteLine("errror!");
            }

        }

        public void GetEmployeeDetails()
        {
            /* object a = 10;
             int value = (int) a;
             object b = "aeeee";
            */

            /*   ArrayList employeeList=new ArrayList();
               employeeList.Add(11);
               employeeList.Capacity = 12;
               employeeList.Add("chandan");
               employeeList.Add(true);
               employeeList.Add(0.555);
               for(int i = 0; i < employeeList.Count; i++)
               {
                   Console.WriteLine(employeeList[i]);
               }*/


            /* Console.WriteLine("************");
             Console.WriteLine("Reading...");

             Console.Write("Firstname=");
             Console.WriteLine(Firstname);

             Console.Write("Lastname=");
             Console.WriteLine(Lastname);

             Console.Write("Email=");
             Console.WriteLine(Email);

             Console.Write("Mobile=");
             Console.WriteLine(Mobile);

             */
            /*     Stack stackObj = new Stack();
                 stackObj.Push(1);
                 stackObj.Push(2);

                 Console.WriteLine(stackObj.Pop());
               */

            //
            /* public void SearchEmployee(int id)
             {
                 if(id==11)
                 {
                     Console.WriteLine("Reading....");
                     Console.WriteLine("Employee Details: " + Id + "," + Firstname + "," + Lastname + "," + Email + "," + Mobile);

                 }
             }
             public void SearchEmployee(string name)
             {
                 if(name=="Rajesh")
                 {
                     Console.WriteLine("Reading....");
                     Console.WriteLine("Employee Details: " + Id + "," + Firstname + "," + Lastname + "," + Email + "," + Mobile);
                 }
             }

             public void SearchEmployee(double salary)
             {
                 if (salary == 10.45)
                 {
                     Console.WriteLine("Reading....");
                     Console.WriteLine("Employee Details: " + Id + "," + Firstname + "," + Lastname + "," + Email + "," + Mobile);
                 }

               */
            List<int> values = new List<int>();
            values.Add(11);
            List<string> nameValues = new List<string>();
            nameValues.Add("chandan");
            List<double> salaryValues = new List<double>();
            salaryValues.Add(232.22);
            
            List<Employee> employee=new List<Employee>();
            Employee employeeObj=new Employee();
            employeeObj.Email = "chandawn@dsfgsnd.com";
            employeeObj.Firstname = "chandana";
            employeeObj.Mobile = 234234;
            employeeObj.Id = 343;
            employee.Add(employeeObj);

            employeeObj = new Employee();
            employeeObj.Email = "NMMchandawn@dsfgsnd.com";
            employeeObj.Firstname = "BMBMBchandana";
            employeeObj.Mobile = 534234;
            employeeObj.Id = 312;
            employee.Add(employeeObj);

            foreach(var item in employee)
            {
                Console.WriteLine(item.Id);
                Console.WriteLine(item.Firstname);
            }
        }
        public void SearchEmployee<T>(T input)
        {
            Console.WriteLine("My input: " + input);
        }
    }
}
