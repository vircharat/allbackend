﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c_sharp_training
{
    public enum chan
    {
        abc = 1,
        efg = 2
    }
    class Program
    {   
        static void Main(string[] args)
        {  /* Employee employeeObj=new Employee();
            employeeObj.Firstname = "chandan";
            employeeObj.CreateEmployee();
            employeeObj.UpdateEmployee();
            employeeObj.GetEmployeeDetails();
            
           
            Console.WriteLine("************");
            employeeObj.SearchEmployee("Rajesh");
            Console.Read();*/


            /* Nokia nokiaObj = new Nokia();
             nokiaObj.Year = 2002;
             nokiaObj.Model = "123";
             nokiaObj.NokiaConfig();

            // Mobile mobileObj=new Mobile();

             samsung samsungObj=new samsung();
             samsungObj.Year = 2003;
             samsungObj.Model = "20";



 */
            /* var f = 10.25;
             Employee employeeObj = new Employee();
             Mobile mobile = new Nokia();
             employeeObj.CreateEmployee();*/
            /*  Console.WriteLine("{0}{1}{2}",byte.MaxValue,int.MinValue,int.MinValue);
              var f = 10.25f;*/
            /*
                        int a = 10;
                        int b = 3;
                        Console.WriteLine(a/ (float)b);*/
            /*Employee employee = new Employee();*/

            //employee.GetEmployeeName();
            /*       employee.SearchEmployee<int>(12);
                   employee.SearchEmployee<string>("san");
                   employee.SearchEmployee<bool>(true);
                   employee.SearchEmployee<double>(4000);
                   employee.SearchEmployee<object>*/
            /*(123);
            employee.GetEmployeeDetails();*/

            var mw = chan.abc;

           

        }
    }
}
/* int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int c = a + b;
            Console.WriteLine(c);
            Console.Write("comdnvsnvkijsdnvdfvjid");
            for (int i=0;i<4;i++)
            {


             }
           
          
            Console.Read();*/